#include <stdint.h>
#include <nrf_gpio.h>
#include <nrf_delay.h>
#include <stdio.h>
#include <string.h>
#include <nrf_drv_pwm.h>
#include <nrf_drv_twi.h>
#include <nrf_drv_gpiote.h>
#include "nrf_log.h"
#include "board_camera.h"
#include "board_camera_init.h"

#define PWM_MCLK_PIN        23
#define ARDUINO_SCL_PIN     27
#define ARDUINO_SDA_PIN     26
#define HM01B0_PIN_VSYNC    8
#define HM01B0_PIN_HSYNC    9
#define HM01B0_PIN_PXCLK    10


#define HM01B0_PIN_D0       0
#define HM01B0_PIN_D1       1
#define HM01B0_PIN_D2       2
#define HM01B0_PIN_D3       3
#define HM01B0_PIN_D4       4
#define HM01B0_PIN_D5       5
#define HM01B0_PIN_D6       6
#define HM01B0_PIN_D7       7

#define GET_BIT(num, bit)   ((num>>bit) & 1)

static nrf_drv_pwm_t m_pwm0 = NRF_DRV_PWM_INSTANCE(0);

/* TWI instance. */
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(0);

/* Indicates if operation on TWI has ended. */
static volatile bool m_xfer_done = false;

// This is for tracking PWM instances being used, so we can unintialize only
// the relevant ones when switching from one demo to another.
#define USED_PWM(idx) (1UL << idx)
static uint8_t m_used = 0;

#define HM01B0_SENSOR_ID      0x24

static void PWM_MCLK(void)
{
    NRF_LOG_INFO("PWM_MCLK 8MHZ start");

    /*
     * This demo uses only one channel, which is reflected on LED 1.
     * The LED blinks three times (200 ms on, 200 ms off), then it stays off
     * for one second.
     * This scheme is performed three times before the peripheral is stopped.
     */

    nrf_drv_pwm_config_t const config0 =
    {
        .output_pins =
        {
            PWM_MCLK_PIN | NRF_DRV_PWM_PIN_INVERTED, // channel 0
            NRF_DRV_PWM_PIN_NOT_USED,             // channel 1
            NRF_DRV_PWM_PIN_NOT_USED,             // channel 2
            NRF_DRV_PWM_PIN_NOT_USED,             // channel 3
        },
        .irq_priority = APP_IRQ_PRIORITY_LOWEST,
        .base_clock   = NRF_PWM_CLK_16MHz,
        .count_mode   = NRF_PWM_MODE_UP,
        .top_value    = 255,
        .load_mode    = NRF_PWM_LOAD_COMMON,
        .step_mode    = NRF_PWM_STEP_AUTO
    };
    APP_ERROR_CHECK(nrf_drv_pwm_init(&m_pwm0, &config0, NULL));
    //m_used |= USED_PWM(0);

    // while(1)
    // {
        // This array cannot be allocated on stack (hence "static") and it must
        // be in RAM (hence no "const", though its content is not changed).
        static uint16_t /*const*/ seq_values[] = {128, 0};
        nrf_pwm_sequence_t const seq =
        {
            .values.p_common = seq_values,
            .length          = NRF_PWM_VALUES_LENGTH(seq_values),
            .repeats         = 0,
            .end_delay       = 0
        };

        (void)nrf_drv_pwm_simple_playback(&m_pwm0, &seq, 1, NRF_DRV_PWM_FLAG_LOOP);
    // }
    NRF_LOG_INFO("PWM_MCLK 8MHZ end");
}

void board_cam_pin_init()
{
#if 0
	nrf_gpio_cfg_output(1);
	nrf_gpio_cfg_output(1);
	nrf_gpio_cfg_output(1);
#endif
    nrf_delay_ms(1);
    nrf_delay_us(1);
}

#if 0
static uint8_t m_sample;

__STATIC_INLINE void data_handler(uint8_t temp)
{
    NRF_LOG_INFO("Temperature: %d Celsius degrees.", temp);
}

void twi_handler(nrf_drv_twi_evt_t const * p_event, void * p_context)
{
    switch (p_event->type)
    {
        case NRF_DRV_TWI_EVT_DONE:
            if (p_event->xfer_desc.type == NRF_DRV_TWI_XFER_RX)
            {
                data_handler(m_sample);
            }
            m_xfer_done = true;
            break;
        default:
            break;
    }
}
#endif

void hm01b0_twi_init(void)
{
    NRF_LOG_INFO("twi0_start");
    ret_code_t err_code;

    const nrf_drv_twi_config_t twi_hm01b0_config = {
       .scl                = ARDUINO_SCL_PIN,
       .sda                = ARDUINO_SDA_PIN,
       .frequency          = NRF_DRV_TWI_FREQ_100K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
       .clear_bus_init     = true
    };

    // err_code = nrf_drv_twi_init(&m_twi, &twi_hm01b0_config, twi_handler, NULL);
    err_code = nrf_drv_twi_init(&m_twi, &twi_hm01b0_config, NULL, NULL);
    APP_ERROR_CHECK(err_code);

    nrf_drv_twi_enable(&m_twi);
    NRF_LOG_INFO("twi0_end");
}

uint32_t hm01b0_write_reg(uint16_t addr16, uint8_t value)
{
    ret_code_t err_code;

		NRF_LOG_INFO("W REG START");
	  /* Writing to LM75B_REG_CONF "0" set temperature sensor in NORMAL mode. */
    uint8_t reg[3] = {(uint8_t)(addr16 >> 8) & 0xFF, (uint8_t)(addr16)&0xFF, value};
    err_code = nrf_drv_twi_tx(&m_twi, HM01B0_SENSOR_ID, reg, sizeof(reg), false);
    APP_ERROR_CHECK(err_code);
		NRF_LOG_INFO("W REG START");
    //while (m_xfer_done == false);
}

uint32_t hm01b0_read_reg(uint16_t addr16, uint8_t *value, uint8_t number_rd)
{
    ret_code_t err_code;

		NRF_LOG_INFO("READ REG START");
    /* Writing to LM75B_REG_CONF "0" set temperature sensor in NORMAL mode. */
    uint8_t reg[2] = {(uint8_t)(addr16 >> 8) & 0xFF, (uint8_t)(addr16)&0xFF};
    err_code = nrf_drv_twi_tx(&m_twi, HM01B0_SENSOR_ID, reg, sizeof(reg), true);
		nrf_delay_ms(20);
    err_code = nrf_drv_twi_rx(&m_twi, HM01B0_SENSOR_ID, value, number_rd);

    APP_ERROR_CHECK(err_code);
		NRF_LOG_INFO("READ REG END");
    //while (m_xfer_done == false);
}

void hm01b0_init_regs(struct senosr_reg *regs_list) {
    NRF_LOG_INFO("hm01b0_init_regs start");
    while (1) {
        uint16_t reg   = regs_list->reg;
        uint8_t  value = regs_list->val;

        NRF_LOG_INFO("hm01b0_init_regs");
        if (reg == 0xFFFF && value == 0xFF) {
          break;
        }

        hm01b0_write_reg(reg, value);
        regs_list++;
  }
  NRF_LOG_INFO("hm01b0_init_regs end");
}

void hm01b0_init()
{
	//enable the clk
    PWM_MCLK();
	//reset the camera
    hm01b0_twi_init();
	//init camera regs
    // hm01b0_init_regs(hm01b0_324x244);

}

static uint32_t one_frame_done = 0x00;
static uint8_t pui8Buffer[HM01B0_PIXEL_X_NUM*HM01B0_PIXEL_Y_NUM] = {0};

static void hm01b0_data_pin_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{

    uint32_t    pixel_d0;
    uint32_t    pixel_d1;
    uint32_t    pixel_d2;
    uint32_t    pixel_d3;
    uint32_t    pixel_d4;
    uint32_t    pixel_d5;
    uint32_t    pixel_d6;
    uint32_t    pixel_d7;
    uint32_t    ui32Idx = 0; 

    bool vsync_is_set = nrf_drv_gpiote_in_is_set(HM01B0_PIN_VSYNC);
    bool hsync_is_set = nrf_drv_gpiote_in_is_set(HM01B0_PIN_HSYNC);
    bool pxclk_is_set = nrf_drv_gpiote_in_is_set(HM01B0_PIN_PXCLK);

    uint32_t    ui32HsyncCnt    = 0x00;

    while((ui32HsyncCnt < HM01B0_PIXEL_Y_NUM))
    {

        while(0x00 == hsync_is_set);

        while(hsync_is_set)
        {
            while(0x00 == pxclk_is_set);

            switch (pin)
            {
            //one time each PIN 32bit 
            case HM01B0_PIN_D0:
                pixel_d0 = nrf_gpio_pin_input_get(HM01B0_PIN_D0);
            case HM01B0_PIN_D1:
                pixel_d1 = nrf_gpio_pin_input_get(HM01B0_PIN_D1);
            case HM01B0_PIN_D2:
                pixel_d2 = nrf_gpio_pin_input_get(HM01B0_PIN_D2);
            case HM01B0_PIN_D3:
                pixel_d3 = nrf_gpio_pin_input_get(HM01B0_PIN_D3);
            case HM01B0_PIN_D4:
                pixel_d4 = nrf_gpio_pin_input_get(HM01B0_PIN_D4);
            case HM01B0_PIN_D5:
                pixel_d5 = nrf_gpio_pin_input_get(HM01B0_PIN_D5);
            case HM01B0_PIN_D6:
                pixel_d6 = nrf_gpio_pin_input_get(HM01B0_PIN_D6);
            case HM01B0_PIN_D7:
                pixel_d7 = nrf_gpio_pin_input_get(HM01B0_PIN_D7);
                break;

                default:
                    break;
            }
            //MERGE PIN0-PIN8 DATA
            for (int i = 0; i < 32; ++i)
            {
              *(pui8Buffer + (ui32Idx+i)) = GET_BIT(pixel_d0, i) | GET_BIT(pixel_d1, i) |
                                        GET_BIT(pixel_d2, i) | GET_BIT(pixel_d3, i) |
                                        GET_BIT(pixel_d4, i) | GET_BIT(pixel_d5, i) |
                                        GET_BIT(pixel_d6, i) | GET_BIT(pixel_d7, i);
            }

            if (ui32Idx == HM01B0_PIXEL_X_NUM*HM01B0_PIXEL_Y_NUM) {
                goto end;
            }

            while(pxclk_is_set);

            ui32HsyncCnt+= 32;
        }
    }

end:
    printf("[%s] - Byte Counts %d\n", __func__, ui32Idx);
    one_frame_done = 1;

}

void hm01b0_pin_gpiote_init(void)
{
    ret_code_t err_code;

    err_code = nrf_drv_gpiote_init();
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_in_config_t in_config = GPIOTE_CONFIG_IN_SENSE_HITOLO(true);
    in_config.pull = NRF_GPIO_PIN_PULLUP;

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D0, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D1, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D2, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D3, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D4, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D5, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D6, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_D7, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_VSYNC, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_HSYNC, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(HM01B0_PIN_PXCLK, &in_config, hm01b0_data_pin_handler);
    APP_ERROR_CHECK(err_code);

    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D0, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D1, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D2, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D3, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D4, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D5, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D6, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_D7, true);

    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_VSYNC, true);
    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_HSYNC, true);

    nrf_drv_gpiote_in_event_enable(HM01B0_PIN_PXCLK, true);


}

#if 0
uint8_t hm01b0_read_hsync()
{

}

uint8_t hm01b0_read_pclk()
{

}

uint8_t hm01b0_read_byte()
{
    
}
#endif

uint32_t hm01b0_blocking_read_oneframe(uint8_t *oneframebuffer)
{
    uint32_t i;
    for (i = 0; i < HM01B0_PIXEL_Y_NUM * HM01B0_PIXEL_Y_NUM; ++i)
    {
        oneframebuffer[i] = pui8Buffer[i];
    }    
}

void unit_pwm_test()
{
    PWM_MCLK();
}

#if defined(BOARD_PCA10100)
/**
 * Function for configuring UICR_REGOUT0 register
 * to set GPIO output voltage to 3.0V.
 */
static void gpio_output_voltage_setup(void)
{
    // Configure UICR_REGOUT0 register only if it is set to default value.
    if ((NRF_UICR->REGOUT0 & UICR_REGOUT0_VOUT_Msk) ==
        (UICR_REGOUT0_VOUT_DEFAULT << UICR_REGOUT0_VOUT_Pos))
    {
        NRF_NVMC->CONFIG = NVMC_CONFIG_WEN_Wen;
        while (NRF_NVMC->READY == NVMC_READY_READY_Busy){}

        NRF_UICR->REGOUT0 = (NRF_UICR->REGOUT0 & ~((uint32_t)UICR_REGOUT0_VOUT_Msk)) |
                            (UICR_REGOUT0_VOUT_2V7 << UICR_REGOUT0_VOUT_Pos);

        NRF_NVMC->CONFIG = NVMC_CONFIG_WEN_Ren;
        while (NRF_NVMC->READY == NVMC_READY_READY_Busy){}

        // System reset is needed to update UICR registers.
        NVIC_SystemReset();
    }
}
#endif

#define TWI_ADDRESSES      127

void unit_twi_test()
{
    NRF_LOG_INFO("unit_pwm_test start 0");
    uint8_t sensorIDH[1];
    uint8_t sensorIDL[1];

    uint8_t address;
    uint8_t m_sample;
    uint8_t sample_data;
    uint8_t sample_data1;
    bool detected_device = false;
    int err_code = 0;

    // gpio_output_voltage_setup();
    hm01b0_init();

    NRF_LOG_INFO("TWI detection start");
	#if 1
    for (address = 1; address <= TWI_ADDRESSES; address++)
    {
        err_code = nrf_drv_twi_rx(&m_twi, address, &sample_data, sizeof(sample_data));
		//NRF_LOG_INFO("TWI error code 0x%x.", err_code);
        if (err_code == NRF_SUCCESS)
        {
            detected_device = true;
            NRF_LOG_INFO("TWI device detected at address 0x%x.", address);
        }
        //NRF_LOG_FLUSH();
    }
    if (!detected_device)
    {
        NRF_LOG_INFO("Test 16 No device was found.");
        //NRF_LOG_FLUSH();
    }
	#endif
    NRF_LOG_INFO("TWI detection end");
		
		#if 1
		uint8_t reg[2] = {(uint8_t)(0x0000 >> 8) & 0xFF, (uint8_t)(0x0000)&0xFF};
		err_code = nrf_drv_twi_tx(&m_twi, HM01B0_SENSOR_ID, reg, sizeof(reg), false);
		err_code = nrf_drv_twi_rx(&m_twi, HM01B0_SENSOR_ID, &m_sample, sizeof(m_sample));
		NRF_LOG_INFO("OUT add handler 0x0000 TWI device detected sample[0] = 0x%x.", m_sample);
		NRF_LOG_INFO("TWI error code 0x%x.", err_code);
		nrf_delay_ms(10);
		uint8_t reg_two[2] = {(uint8_t)(0x0001 >> 8) & 0xFF, (uint8_t)(0x0001)&0xFF};
		err_code = nrf_drv_twi_tx(&m_twi, HM01B0_SENSOR_ID, reg_two, sizeof(reg_two), false);
		err_code = nrf_drv_twi_rx(&m_twi, HM01B0_SENSOR_ID, &m_sample, sizeof(m_sample));
		NRF_LOG_INFO("OUT add 0x0001 TWI device detected sample[1] = 0x%x.", m_sample);
		NRF_LOG_INFO("TWI error code 0x%x.", err_code);
        if (err_code == NRF_SUCCESS)
        {
            NRF_LOG_INFO("TWI device detected sample 0x%x.", sample_data);
        }
		#endif

    //hm01b0_read_reg(0x0000, sensorIDH, 1);
    //hm01b0_read_reg(0x0001, sensorIDL, 1);

    //NRF_LOG_INFO("sensorIDL = 0x%x\n", sensorIDL[0]);
    //NRF_LOG_INFO("sensorIDH = 0x%x\n", sensorIDH[0]);

    NRF_LOG_INFO("unit_pwm_test end 0");
}

void unit_gpiote_test()
{
    hm01b0_pin_gpiote_init();
}

void unit_captrue_test()
{
    uint8_t CamBuffer[HM01B0_PIXEL_X_NUM*HM01B0_PIXEL_Y_NUM] = {0};

    unit_twi_test();
    unit_gpiote_test();

    hm01b0_blocking_read_oneframe(CamBuffer);

    for (int i = 0; i < HM01B0_PIXEL_X_NUM*HM01B0_PIXEL_Y_NUM; ++i)
       NRF_LOG_INFO("CamBuffer = 0x%x\n", CamBuffer[i]);

}