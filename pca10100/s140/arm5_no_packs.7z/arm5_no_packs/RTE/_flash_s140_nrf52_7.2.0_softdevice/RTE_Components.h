
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ble_app_uart_pca10100_s140' 
 * Target:  'flash_s140_nrf52_7.2.0_softdevice' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "nrf.h"



#endif /* RTE_COMPONENTS_H */
