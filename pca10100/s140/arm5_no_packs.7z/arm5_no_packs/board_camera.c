#include <stdint.h>
#include <nrf_gpio.h>
#include <nrf_delay.h>
#include <stdio.h>
#include <string.h>
#include <nrf_drv_pwm.h>
#include <nrfx.h>
#include "nrf_log.h"
#include "board_camera.h"

int PIN_LED = 25;

int PIN_CAM_SIOD = 18; // I2C0 SDA
int PIN_CAM_SIOC = 19; // I2C0 SCL
int PIN_CAM_RESETB = 2;
int PIN_POWER_EN = 5;
int PIN_CAM_XCLK = 3;
int PIN_CAM_VSYNC = 16;     //GP15 hsync  GP14 pixel clock     
int PIN_CAM_Y2_PIO_BASE = 6;   // data GPIO6

#if defined (SOFTWARE_I2C)
#define SCCB_SIC_H()      nrf_gpio_pin_write(PIN_CAM_SIOC,1)	 	//SCL H
#define SCCB_SIC_L()      nrf_gpio_pin_write(PIN_CAM_SIOC,0)		 	//SCL H
#define SCCB_SID_H()      nrf_gpio_pin_write(PIN_CAM_SIOD,1)   //SDA	H
#define SCCB_SID_L()      nrf_gpio_pin_write(PIN_CAM_SIOD,0)    //SDA	H 
#define SCCB_DATA_IN      nrf_gpio_pin_dir_set(PIN_CAM_SIOD, GPIO_PIN_CNF_DIR_Input);
#define SCCB_DATA_OUT     nrf_gpio_pin_dir_set(PIN_CAM_SIOD, GPIO_PIN_CNF_DIR_Output);
#define SCCB_SID_STATE	  nrf_gpio_pin_dir_get(PIN_CAM_SIOD)
void sccb_bus_init(void);
void sccb_bus_start(void);
void sccb_bus_stop(void);
void sccb_bus_send_noack(void);
void sccb_bus_send_ack(void);
unsigned char sccb_bus_write_byte(unsigned char data);
unsigned char sccb_bus_read_byte(void);
unsigned char I2C_TIM;


static nrf_drv_pwm_t m_pwm0 = NRF_DRV_PWM_INSTANCE(0);

// This is for tracking PWM instances being used, so we can unintialize only
// the relevant ones when switching from one demo to another.
#define USED_PWM(idx) (1UL << idx)
static uint8_t m_used = 0;


static uint16_t const              m_demo1_top  = 10000;
static uint16_t const              m_demo1_step = 200;
static uint8_t                     m_demo1_phase;
static nrf_pwm_values_individual_t m_demo1_seq_values;
static nrf_pwm_sequence_t const    m_demo1_seq =
{
    .values.p_individual = &m_demo1_seq_values,
    .length              = NRF_PWM_VALUES_LENGTH(m_demo1_seq_values),
    .repeats             = 0,
    .end_delay           = 0
};

static void demo1_handler(nrf_drv_pwm_evt_type_t event_type)
{
    if (event_type == NRF_DRV_PWM_EVT_FINISHED)
    {
        uint8_t channel    = m_demo1_phase >> 1;
        bool    down       = m_demo1_phase & 1;
        bool    next_phase = false;

        uint16_t * p_channels = (uint16_t *)&m_demo1_seq_values;
        uint16_t value = p_channels[channel];
        if (down)
        {
            value -= m_demo1_step;
            if (value == 0)
            {
                next_phase = true;
            }
        }
        else
        {
            value += m_demo1_step;
            if (value >= m_demo1_top)
            {
                next_phase = true;
            }
        }
        p_channels[channel] = value;

        if (next_phase)
        {
            if (++m_demo1_phase >= 2 * NRF_PWM_CHANNEL_COUNT)
            {
                m_demo1_phase = 0;
            }
        }
    }
}
static void PWM_XCLK(void)
{
    NRF_LOG_INFO("Demo 1");

    /*
     * This demo plays back a sequence with different values for individual
     * channels (LED 1 - LED 4). Only four values are used (one per channel).
     * Every time the values are loaded into the compare registers, they are
     * updated in the provided event handler. The values are updated in such
     * a way that increase and decrease of the light intensity can be observed
     * continuously on succeeding channels (one second per channel).
     */

    nrf_drv_pwm_config_t const config0 =
    {
        .output_pins =
        {
            PIN_CAM_XCLK | NRF_DRV_PWM_PIN_INVERTED, // channel 0
        },
        .irq_priority = APP_IRQ_PRIORITY_LOWEST,
        .base_clock   = NRF_PWM_CLK_16MHz,
        .count_mode   = NRF_PWM_MODE_UP,
        .top_value    = m_demo1_top,
        .load_mode    = NRF_PWM_LOAD_INDIVIDUAL,
        .step_mode    = NRF_PWM_STEP_AUTO
    };
    APP_ERROR_CHECK(nrf_drv_pwm_init(&m_pwm0, &config0, demo1_handler));
    m_used |= USED_PWM(0);

    m_demo1_seq_values.channel_0 = 0;
    m_demo1_seq_values.channel_1 = 0;
    m_demo1_seq_values.channel_2 = 0;
    m_demo1_seq_values.channel_3 = 0;
    m_demo1_phase                = 0;

    (void)nrf_drv_pwm_simple_playback(&m_pwm0, &m_demo1_seq, 1,
                                      NRF_DRV_PWM_FLAG_LOOP);
}

void boardcam_pin_init( void )
{
	
		
    // Workaround for PAN_028 rev1.1 anomaly 22 - System: Issues with disable System OFF mechanism
    nrf_delay_ms(1);
    nrf_delay_us(1);
}

void sccb_bus_start(void)
{
    SCCB_SID_H();             
    sleep_us(I2C_TIM);
    SCCB_SIC_H();	           
    sleep_us(I2C_TIM);
    SCCB_SID_L();
    sleep_us(I2C_TIM);
    SCCB_SIC_L();	           
    sleep_us(I2C_TIM);
}

void sccb_bus_stop(void)
{
    SCCB_SID_L();
    sleep_us(I2C_TIM);
    SCCB_SIC_H();	
    sleep_us(I2C_TIM);  
    SCCB_SID_H();	
    sleep_us(I2C_TIM);  
}

void sccb_bus_send_noack(void)
{	
	SCCB_SID_H();	
	sleep_us(I2C_TIM);	
	SCCB_SIC_H();	
	sleep_us(I2C_TIM);	
	SCCB_SIC_L();	
	sleep_us(I2C_TIM);	
	SCCB_SID_L();	
	sleep_us(I2C_TIM);
}

void sccb_bus_send_ack(void)
{	
	SCCB_SID_L();	
	sleep_us(I2C_TIM);	
	SCCB_SIC_L();	
	sleep_us(I2C_TIM);	
	SCCB_SIC_H();	
	sleep_us(I2C_TIM);	
	SCCB_SIC_L();	
	sleep_us(I2C_TIM);	
	SCCB_SID_L();	
	sleep_us(I2C_TIM);
}

unsigned char sccb_bus_write_byte(unsigned char data)
{
	unsigned char i;
	unsigned char tem;
	for(i = 0; i < 8; i++) 
	{
		if((data<<i) & 0x80)
		{
			SCCB_SID_H();
		}
		else 
		{
			SCCB_SID_L();
		}
		sleep_us(I2C_TIM);
		SCCB_SIC_H();	
		sleep_us(I2C_TIM);
		SCCB_SIC_L();	
	}
	SCCB_DATA_IN;
	sleep_us(I2C_TIM);
	SCCB_SIC_H();	
	sleep_us(I2C_TIM);
	if(SCCB_SID_STATE)
	{
		tem = 0;              
	}
	else 
	{
		tem = 1;               
	}

	SCCB_SIC_L();	
	sleep_us(I2C_TIM);	
	SCCB_DATA_OUT;
	return tem;  
}

unsigned char sccb_bus_read_byte(void)
{	
	unsigned char i;
	unsigned char read = 0;
	SCCB_DATA_IN;
	for(i = 8; i > 0; i--)
	{		     
		sleep_us(I2C_TIM);
		SCCB_SIC_H();
		sleep_us(I2C_TIM);
		read = read << 1;
		if(SCCB_SID_STATE)
		{
			read += 1; 
		}
		SCCB_SIC_L();
		sleep_us(I2C_TIM);
	}	
    SCCB_DATA_OUT;
	return read;
}

unsigned char wrSensorReg16_8( uint8_t slave_address, int regID, int regDat)
{
	sccb_bus_start();
	if(0==sccb_bus_write_byte(slave_address<<1))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(10);
  if(0==sccb_bus_write_byte(regID>>8))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(10);
  if(0==sccb_bus_write_byte(regID))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(10);
  if(0==sccb_bus_write_byte(regDat))
	{
		sccb_bus_stop();
		return(0);
	}
  sccb_bus_stop();
	
  return(1);
}


unsigned char rdSensorReg16_8(uint8_t slave_address, unsigned int regID, unsigned char* regDat)
{
	sccb_bus_start();                  
	if(0==sccb_bus_write_byte(slave_address<<1))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(20);
	sleep_us(20);
  if(0==sccb_bus_write_byte(regID>>8))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(20);
  if(0==sccb_bus_write_byte(regID))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(20);
	sccb_bus_stop();
	
	sleep_us(20);
	
	
	sccb_bus_start();                 
	if(0==sccb_bus_write_byte((slave_address<<1)|0x01))
	{
		sccb_bus_stop();
		return(0);
	}
	sleep_us(20);
  *regDat=sccb_bus_read_byte();
  sccb_bus_send_noack();
  sccb_bus_stop();
  return(1);
}
#endif

void boardcam_reg_write(struct boardcam_config *config, uint16_t reg, uint8_t value) {
	uint8_t data[3];
	uint8_t length =0;
	switch (config->sccb_mode){
		case I2C_MODE_16_8:
			data[0] = (uint8_t)(reg>>8)&0xFF;
			data[1] = (uint8_t)(reg)&0xFF;
			data[2] = value;
			length = 3;
			break;
		case I2C_MODE_8_8:
			data[0] = (uint8_t)(reg)&0xFF;
			data[1] = value;
			length = 2; 
			break;
	}
	//printf("length: %x data[0]: = %x  data[1] = %x data[2] = %x\r\n", length, data[0],data[1],data[2]);
	int ret = wrSensorReg16_8(config->sensor_address, reg, value);
	//printf("ret: %x\r\n", ret);
}

void boardcam_regs_write(struct boardcam_config *config, struct senosr_reg* regs_list) {
	while (1) {
		uint16_t reg = regs_list->reg;
		uint8_t value = regs_list->val;
		
		if (reg == 0xFFFF && value == 0xFF) {
			break;
		}
		//printf("reg: 0x%04x , val: 0x%02x\r\n",reg, value);
		boardcam_reg_write(config, reg, value);

		regs_list++;
	}
}

void board_cam_pin_init()
{
	nrf_gpio_cfg_output(PIN_CAM_SIOC);
	nrf_gpio_cfg_output(PIN_CAM_SIOD);
	nrf_gpio_cfg_output(PIN_CAM_RESETB);
	
}

void boardcam_init()
{
	//enable the clk

	//reset the camera
	
	//init camera regs

	//enable image data rx

}

