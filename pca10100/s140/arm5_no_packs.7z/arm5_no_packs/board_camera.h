#ifndef BOARD_CAMERA_H__
#define BOARD_CAMERA_H__

#include <stdint.h>
#include <nrf_delay.h>

#define SOFTWARE_I2C

enum i2c_mode{
	I2C_MODE_16_8 = 0,
	I2C_MODE_8_8 = 1,
};

struct senosr_reg{
	uint16_t reg;
	uint8_t  val;
};

struct boardcam_config {
  uint8_t sensor_address;
	enum i2c_mode sccb_mode;
	uint8_t *image_buf;
	uint16_t image_buf_size;
};

void sleep_us(uint8_t us)
{
	nrf_delay_us(us);
}

#endif
